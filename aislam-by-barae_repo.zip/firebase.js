// firebase.js - add your Firebase config here
window.firebaseConfig = {
  apiKey: "REPLACE_FIREBASE_APIKEY",
  authDomain: "REPLACE_AUTHDOMAIN",
  projectId: "aislam-by-barae",
  storageBucket: "REPLACE_STORAGE",
  messagingSenderId: "REPLACE_MSGID",
  appId: "REPLACE_APPID"
};