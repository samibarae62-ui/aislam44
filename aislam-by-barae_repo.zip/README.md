# AiSlam Pro - aislam-by-barae

مشروع AiSlam Pro تم تطويره بواسطة Barae 🇲🇦 – مطوّر تطبيقات ذكاء اصطناعي واجتماعية.

## محتويات
- index.html
- style.css
- firebase.js (أدخل إعدادات Firebase هنا)
- config.js (أدخل مفاتيح OpenAI وGoogle Translate هنا)
- app.js (تطبيق React جاهز)

## سريع
- لبدء التشغيل: ضع مفاتيح Firebase وGoogle Translate في الملفات أعلاه، ثم ارفع المحتوى إلى GitHub أو Netlify.
- للمساعدة في النشر، أخبرني وسأرشدك خطوة بخطوة.
