// AiSlam app (React) - includes language selector (wide list), dark mode, Firebase placeholders and OpenAI demo key
const {useState,useEffect,useRef}=React;

/* --------- CONFIG (edit these before deploying) --------- */
const firebaseConfig = {
  apiKey: "PLACEHOLDER_FIREBASE_APIKEY",
  authDomain: "PLACEHOLDER_AUTHDOMAIN",
  projectId: "aislam-app",
  storageBucket: "PLACEHOLDER_BUCKET",
  messagingSenderId: "PLACEHOLDER_MSG",
  appId: "PLACEHOLDER_APPID"
};
firebase.initializeApp(firebaseConfig);
const auth = firebase.auth();
const db = firebase.firestore();

// Demo/test OpenAI key (replace with your own for production)
const OPENAI_API_KEY = "sk-DEMO-PLACEHOLDER";

/* --------- Languages list (comprehensive list of common languages + many more) --------- */
const LANGUAGES = [
  {code:"auto", name:"اكتشاف تلقائي (Auto detect)"},
  {code:"ar", name:"العربية"},
  {code:"en", name:"English"},
  {code:"es", name:"Español"},
  {code:"fr", name:"Français"},
  {code:"de", name:"Deutsch"},
  {code:"pt", name:"Português"},
  {code:"ru", name:"Русский"},
  {code:"zh", name:"中文"},
  {code:"hi", name:"हिन्दी"},
  {code:"bn", name:"বাংলা"},
  {code:"ja", name:"日本語"},
  {code:"ko", name:"한국어"},
  {code:"it", name:"Italiano"},
  {code:"nl", name:"Nederlands"},
  {code:"sv", name:"Svenska"},
  {code:"no", name:"Norsk"},
  {code:"fi", name:"Suomi"},
  {code:"da", name:"Dansk"},
  {code:"tr", name:"Türkçe"},
  {code:"pl", name:"Polski"},
  {code:"vi", name:"Tiếng Việt"},
  {code:"th", name:"ไทย"},
  {code:"id", name:"Bahasa Indonesia"},
  {code:"ms", name:"Bahasa Melayu"},
  {code:"he", name:"עברית"},
  {code:"fa", name:"فارسی"},
  {code:"ur", name:"اردو"},
  {code:"sw", name:"Kiswahili"},
  {code:"am", name:"አማርኛ"},
  {code:"tl", name:"Filipino"},
  {code:"cs", name:"Čeština"},
  {code:"el", name:"Ελληνικά"},
  {code:"hu", name:"Magyar"},
  {code:"ro", name:"Română"},
  {code:"bg", name:"Български"},
  {code:"hr", name:"Hrvatski"},
  {code:"sr", name:"Srpski"},
  {code:"sk", name:"Slovenčina"},
  {code:"sl", name:"Slovenščina"},
  {code:"lt", name:"Lietuvių"},
  {code:"lv", name:"Latviešu"},
  {code:"et", name:"Eesti"},
  {code:"is", name:"Íslenska"},
  {code:"ga", name:"Gaeilge"},
  {code:"mk", name:"Македонски"},
  {code:"sq", name:"Shqip"},
  {code:"bn", name:"বাংলা"},
  {code:"ne", name:"नेपाली"},
  {code:"si", name:"සිංහල"},
  {code:"km", name:"ភាសាខ្មែរ"},
  {code:"lo", name:"ພາສາລາວ"},
  {code:"my", name:"မြန်မာစာ"},
  {code:"mn", name:"Монгол"},
  // note: list can be expanded; includes dozens of language codes
];

/* Minimal translation map for common UI strings.
   For 'all languages' requirement we provide a comprehensive selector and auto-detect;
   UI labels fallback to English/Arabic if translation missing. */
const TRANSLATIONS = {
  en:{
    title: "AiSlam",
    create: "Create",
    home: "Home",
    chat: "Chat",
    camera: "Camera",
    login: "Sign in with Google",
    logout: "Sign out",
    publish: "Publish Post",
    summarize: "Summarize"
  },
  ar:{
    title: "AiSlam - بالعقل نرتقي",
    create: "إنشاء",
    home: "الرئيسية",
    chat: "دردشة",
    camera: "كاميرا",
    login: "سجل الدخول بـ Google",
    logout: "تسجيل خروج",
    publish: "نشر منشور",
    summarize: "تلخيص"
  },
  fr:{ title:"AiSlam", create:"Créer", home:"Accueil", chat:"Chat", camera:"Caméra", login:"Se connecter avec Google", logout:"Déconnexion", publish:"Publier", summarize:"Résumer" },
  es:{ title:"AiSlam", create:"Crear", home:"Inicio", chat:"Chat", camera:"Cámara", login:"Iniciar con Google", logout:"Cerrar sesión", publish:"Publicar", summarize:"Resumir" }
};

/* Helper: get translated label */
function t(lang, key){
  if(!lang) lang = localStorage.getItem("aislam_lang") || "auto";
  if(lang === "auto"){
    const nav = (navigator.language || navigator.userLanguage || "en").slice(0,2);
    lang = TRANSLATIONS[nav] ? nav : "en";
  }
  return (TRANSLATIONS[lang] && TRANSLATIONS[lang][key]) || TRANSLATIONS["en"][key] || key;
}

/* ---------- Notification helper ---------- */
const showNotification = (msg) => {
  const n = document.getElementById("notification");
  n.innerText = msg;
  n.classList.add("show");
  setTimeout(()=> n.classList.remove("show"), 2600);
};

/* ---------- Main App ---------- */
function App(){
  const [user,setUser]=useState(null);
  const [tab,setTab]=useState("home");
  const [lang,setLang]=useState(localStorage.getItem("aislam_lang")||"auto");
  const [theme,setTheme]=useState(localStorage.getItem("aislam_theme")||"light");
  const [posts,setPosts]=useState([]);
  const [stories,setStories]=useState([]);
  const [chat,setChat]=useState([]);
  const [text,setText]=useState("");
  const [summary,setSummary]=useState("");
  const videoRef = useRef(null);

  useEffect(()=>{
    document.documentElement.lang = (lang==="auto"? (navigator.language||"en") : lang);
    document.documentElement.dir = ["ar","he","fa","ur"].includes(lang) ? "rtl" : "auto";
    document.documentElement.setAttribute("data-theme", theme==="dark"?"dark":"light");
    localStorage.setItem("aislam_lang", lang);
    localStorage.setItem("aislam_theme", theme);
  },[lang,theme]);

  useEffect(()=>{
    const un = auth.onAuthStateChanged(u => {
      setUser(u);
      if(u) initLive();
    });
    return ()=> un && un();
  },[]);

  const initLive = ()=> {
    db.collection("posts").orderBy("createdAt","desc").limit(50).onSnapshot(snap=> setPosts(snap.docs.map(d=>({id:d.id,...d.data()}))) );
    db.collection("stories").orderBy("createdAt","desc").limit(20).onSnapshot(snap=> setStories(snap.docs.map(d=>({id:d.id,...d.data()}))) );
    db.collection("chat").orderBy("createdAt","asc").limit(200).onSnapshot(snap=> setChat(snap.docs.map(d=>({id:d.id,...d.data()}))) );
  };

  const login = ()=> auth.signInWithPopup(new firebase.auth.GoogleAuthProvider());
  const logout = ()=> { auth.signOut(); setUser(null); showNotification(t(lang,"logout") || "Signed out"); };

  const publishPost = (mediaUrl)=>{
    if(!user) return alert("Please sign in");
    const tcontent = prompt("اكتب نص المنشور (يمكن بأي لغة)...") || "";
    db.collection("posts").add({
      userId: user.uid, userName: user.displayName, text: tcontent, media: mediaUrl||"", likes: [], comments: [], createdAt: firebase.firestore.FieldValue.serverTimestamp()
    }).then(()=> showNotification(t(lang,"publish") || "Published"));
  };

  const addStory = ()=>{
    if(!user) return alert("Login first");
    const url = prompt("رابط صورة القصة (image url)");
    if(!url) return;
    db.collection("stories").add({ userId: user.uid, userName: user.displayName, url, createdAt: firebase.firestore.FieldValue.serverTimestamp() }).then(()=> showNotification("Story added"));
  };

  const sendMessage = (msg)=>{
    if(!user) return alert("Login first");
    if(!msg) return;
    db.collection("chat").add({ fromId: user.uid, fromName: user.displayName, msg, createdAt: firebase.firestore.FieldValue.serverTimestamp() }).then(()=> showNotification("Sent"));
  };

  const toggleLike = (post)=>{
    if(!user) return alert("Login first");
    const likes = post.likes || [];
    const idx = likes.indexOf(user.uid);
    if(idx>=0) likes.splice(idx,1); else likes.push(user.uid);
    db.collection("posts").doc(post.id).update({likes}).then(()=> showNotification("Updated"));
  };

  const addComment = async (post)=>{
    if(!user) return alert("Login first");
    const c = prompt("أدخل تعليقك...");
    if(!c) return;
    const comments = post.comments || [];
    comments.push({user: user.displayName, text: c, at: Date.now()});
    await db.collection("posts").doc(post.id).update({comments});
    showNotification("Comment added");
  };

  const startCamera = async ()=>{
    if(navigator.mediaDevices){
      const stream = await navigator.mediaDevices.getUserMedia({video:true,audio:false});
      if(videoRef.current) videoRef.current.srcObject = stream;
      showNotification("Camera started");
    } else showNotification("Camera not supported");
  };

  const summarizeText = async ()=>{
    if(!text) return alert("اكتب نصًا أولاً");
    showNotification("Summarizing...");
    try{
      const res = await fetch("https://api.openai.com/v1/chat/completions", {
        method: "POST",
        headers: {"Authorization":"Bearer "+OPENAI_API_KEY, "Content-Type":"application/json"},
        body: JSON.stringify({ model:"gpt-4o-mini", messages:[{role:"user", content:"لخص النص التالي باللغة المختارة باختصار وبلغة بسيطة:\\n\\n"+text}], max_tokens:300 })
      });
      const j = await res.json();
      const s = j?.choices?.[0]?.message?.content || "No summary";
      setSummary(s);
      showNotification("Done");
    }catch(e){ console.error(e); showNotification("Error"); }
  };

  /* UI render */
  return React.createElement("div", {className:"container"},

    React.createElement("div",{className:"topbar"},
      React.createElement("div",{className:"title"}, t(lang,"title") || "AiSlam"),
      React.createElement("div",{className:"controls-row"},
        React.createElement("select",{className:"lang-select", value:lang, onChange:e=>setLang(e.target.value)}, LANGUAGES.map(l=> React.createElement("option",{key:l.code, value:l.code}, l.name ))),
        React.createElement("button",{className:"theme-toggle", onClick:()=> setTheme(theme==="dark"?"light":"dark") }, theme==="dark"?"Light":"Dark"),
        user ? React.createElement("button",{className:"small-btn", onClick:logout}, t(lang,"logout")) : React.createElement("button",{className:"btn", onClick:login}, t(lang,"login"))
      )
    ),

    tab==="home" && React.createElement("div", null,
      React.createElement("div",{className:"story-box"},
        React.createElement("div",{className:"story", onClick:()=> publishPost("")}, React.createElement("img",{src:"https://via.placeholder.com/64?text=You", alt:"you"})),
        stories.map(s=> React.createElement("div",{className:"story", key:s.id}, React.createElement("img",{src:s.url, alt:"story"})))
      ),

      React.createElement("div",{className:"card"},
        React.createElement("div",{className:"controls"},
          React.createElement("button",{className:"btn", onClick:()=> publishPost("")}, t(lang,"publish") || "Publish"),
          React.createElement("button",{className:"small-btn", onClick:addStory}, "قصة")
        )
      ),

      posts.map(p=> React.createElement("div",{key:p.id,className:"post"},
        React.createElement("div",{style:{display:"flex",justifyContent:"space-between",alignItems:"center"}},
          React.createElement("strong",null,p.userName || "User"),
          React.createElement("span",null,new Date((p.createdAt && p.createdAt.seconds ? p.createdAt.seconds*1000 : Date.now())).toLocaleString())
        ),
        p.media && React.createElement("img",{src:p.media, alt:"media"}),
        p.text && React.createElement("p",null,p.text),
        React.createElement("div",{className:"controls"},
          React.createElement("div",{className:"like", onClick:()=>toggleLike(p)}, `♥ ${ (p.likes||[]).length }`),
          React.createElement("button",{className:"small-btn", onClick:()=>addComment(p)}, "تعليق")
        ),
        p.comments && p.comments.length > 0 && React.createElement("div",{className:"summary-box"}, p.comments.map((c,i)=> React.createElement("div",{key:i}, `${c.user}: ${c.text || c}` )))
      ))
    ),

    tab==="create" && React.createElement("div",{className:"card"},
      React.createElement("h3",null, t(lang,"create") || "Create"),
      React.createElement("textarea",{rows:4, placeholder:"اكتب الفكرة أو الصيغة هنا...", value:text, onChange:e=>setText(e.target.value)}),
      React.createElement("button",{className:"btn", onClick:summarizeText}, t(lang,"summarize") || "Summarize"),
      summary && React.createElement("div",{className:"summary-box"}, React.createElement("h4",null,"ملخص"), React.createElement("div",null, summary ))
    ),

    tab==="chat" && React.createElement("div",{className:"card"},
      React.createElement("h3",null, t(lang,"chat") || "Chat"),
      React.createElement("div",{className:"summary-box", style:{height:180, overflowY:"auto"}}, chat.map(c=> React.createElement("div",{key:c.id}, React.createElement("strong",null,c.fromName), ": ", c.msg ))),
      React.createElement("input",{className:"input", placeholder:"اكتب رسالة واضغط Enter...", onKeyDown:e=>{ if(e.key==="Enter"){ sendMessage(e.target.value); e.target.value=""; } }})
    ),

    tab==="camera" && React.createElement("div",{className:"card"},
      React.createElement("button",{className:"btn", onClick:startCamera}, t(lang,"camera") || "Camera"),
      React.createElement("video",{ref:videoRef, autoPlay:true, playsInline:true, style:{width:"100%",borderRadius:12,marginTop:8}})
    ),

    React.createElement("div",{className:"bottom-nav"},
      ["home","create","chat","camera"].map(tn=> React.createElement("div",{key:tn, className:`nav-btn ${ ( (tn==="home" && tab==="home") || (tn==="create" && tab==="create") || (tn==="chat" && tab==="chat") || (tn==="camera" && tab==="camera") )? "active":"" } , onClick: ()=>{ setTab(tn); } }, tn==="home"?"الرئيسية": tn==="create"?"إنشاء": tn==="chat"?"دردشة":"كاميرا" ))
    )
  );
}

ReactDOM.createRoot(document.getElementById("app")).render(React.createElement(App));
