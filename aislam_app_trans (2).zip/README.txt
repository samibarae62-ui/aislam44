AiSlam - بالعقل نرتقي

Place your Firebase config in app.js and replace the OPENAI_API_KEY with your key for production.
Note: For production, protect your OpenAI key using a serverless function.